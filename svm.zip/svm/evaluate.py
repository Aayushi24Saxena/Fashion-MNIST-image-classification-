"""
Evaluation and visualization utilities for SVM
"""
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.metrics import confusion_matrix, classification_report
import os


# Fashion-MNIST class names
CLASS_NAMES = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']


def plot_confusion_matrix(y_true, y_pred, save_path=None, class_names=None):
    """Plot confusion matrix"""
    cm = confusion_matrix(y_true, y_pred)
    
    # Use provided class names or default
    labels = class_names if class_names is not None else CLASS_NAMES
    
    # Adjust figure size based on number of classes
    figsize = (6, 5) if len(labels) == 2 else (12, 10)
    
    plt.figure(figsize=figsize)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=labels, yticklabels=labels)
    plt.title('SVM Confusion Matrix', fontsize=16, fontweight='bold')
    plt.ylabel('True Label', fontsize=12)
    plt.xlabel('Predicted Label', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Confusion matrix saved to {save_path}")
    
    plt.close()


def generate_classification_report(y_true, y_pred, save_path=None):
    """Generate and save classification report"""
    report = classification_report(y_true, y_pred, target_names=CLASS_NAMES, digits=4)
    
    print("\nClassification Report:")
    print("=" * 80)
    print(report)
    print("=" * 80)
    
    if save_path:
        with open(save_path, 'w') as f:
            f.write("SVM Classification Report\n")
            f.write("=" * 80 + "\n")
            f.write(report)
            f.write("=" * 80 + "\n")
        print(f"✓ Classification report saved to {save_path}")
    
    return report


def plot_training_summary(results, config, save_path=None):
    """Plot training summary with metrics"""
    fig, ax = plt.subplots(1, 1, figsize=(10, 6))
    
    metrics = ['Train Acc', 'Val Acc']
    values = [results['train_accuracy'], results['val_accuracy']]
    colors = ['#2ecc71', '#3498db']
    
    bars = ax.bar(metrics, values, color=colors, alpha=0.8, edgecolor='black', linewidth=1.5)
    
    # Add value labels on bars
    for bar, value in zip(bars, values):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{value:.2f}%',
                ha='center', va='bottom', fontsize=14, fontweight='bold')
    
    ax.set_ylabel('Accuracy (%)', fontsize=12)
    ax.set_title(f"SVM Performance - {config['experiment_name']}\n"
                 f"Kernel: {config['kernel']}, C: {config['C']}", 
                 fontsize=14, fontweight='bold')
    ax.set_ylim([0, 105])
    ax.grid(axis='y', alpha=0.3)
    
    # Add training time
    ax.text(0.5, 0.95, f"Training Time: {results['train_time']:.2f}s",
            transform=ax.transAxes, ha='center', va='top',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
            fontsize=11)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Training summary saved to {save_path}")
    
    plt.close()


def create_evaluation_report(results, y_test, test_predictions, config, save_dir):
    """
    Create comprehensive evaluation report
    
    Args:
        results: Dictionary with training results
        y_test: True test labels
        test_predictions: Predicted test labels
        config: Configuration dictionary
        save_dir: Directory to save all outputs
    """
    os.makedirs(save_dir, exist_ok=True)
    experiment_name = config['experiment_name']
    
    # 1. Confusion Matrix
    cm_path = os.path.join(save_dir, f'{experiment_name}_confusion_matrix.png')
    plot_confusion_matrix(y_test, test_predictions, save_path=cm_path)
    
    # 2. Training Summary
    summary_path = os.path.join(save_dir, f'{experiment_name}_training_summary.png')
    plot_training_summary(results, config, save_path=summary_path)
    
    # 3. Classification Report
    report_path = os.path.join(save_dir, f'{experiment_name}_classification_report.txt')
    generate_classification_report(y_test, test_predictions, save_path=report_path)
    
    print(f"\n✅ All evaluation reports saved to {save_dir}/")
