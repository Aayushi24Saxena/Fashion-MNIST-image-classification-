"""
Utility functions for SVM - data loading, config parsing
"""
import numpy as np
import yaml
from torchvision import transforms
from torchvision.datasets import FashionMNIST
import os


def load_config(config_path):
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config


def get_data_loaders(config, data_root='data'):
    """
    Load Fashion-MNIST data and convert to numpy arrays for SVM
    
    Args:
        config: Configuration dictionary
        data_root: Root directory for datasets
    
    Returns:
        X_train, y_train, X_val, y_val, X_test, y_test
    """
    # Simple transform - just convert to tensor and normalize
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.2860,), (0.3530,))
    ])
    
    # Load full training dataset
    full_train_dataset = FashionMNIST(
        root=data_root,
        train=True,
        transform=transform,
        download=True
    )
    
    # Load test dataset
    test_dataset = FashionMNIST(
        root=data_root,
        train=False,
        transform=transform,
        download=True
    )
    
    # Convert to numpy arrays and flatten images
    # Training data
    X_train_full = []
    y_train_full = []
    for img, label in full_train_dataset:
        X_train_full.append(img.numpy().flatten())
        y_train_full.append(label)
    
    X_train_full = np.array(X_train_full)
    y_train_full = np.array(y_train_full)
    
    # Split training into train and validation (50000 train, 10000 val)
    train_size = 50000
    X_train = X_train_full[:train_size]
    y_train = y_train_full[:train_size]
    X_val = X_train_full[train_size:]
    y_val = y_train_full[train_size:]
    
    # Test data
    X_test = []
    y_test = []
    for img, label in test_dataset:
        X_test.append(img.numpy().flatten())
        y_test.append(label)
    
    X_test = np.array(X_test)
    y_test = np.array(y_test)
    
    # Option to use subset for faster experimentation
    if config.get('use_subset', False):
        subset_size = config.get('subset_size', 10000)
        print(f"Using subset of {subset_size} training samples for faster training")
        indices = np.random.RandomState(config.get('seed', 42)).permutation(len(X_train))[:subset_size]
        X_train = X_train[indices]
        y_train = y_train[indices]
    
    print(f"Train set: {len(X_train)} samples")
    print(f"Validation set: {len(X_val)} samples")
    print(f"Test set: {len(X_test)} samples")
    print(f"Feature dimension: {X_train.shape[1]}")
    
    return X_train, y_train, X_val, y_val, X_test, y_test


def set_seed(seed):
    """Set random seeds for reproducibility"""
    np.random.seed(seed)
    import random
    random.seed(seed)
