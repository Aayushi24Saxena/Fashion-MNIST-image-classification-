"""
Training and evaluation functions for SVM
"""
import numpy as np
from sklearn.metrics import accuracy_score
import time


def train_model(model, X_train, y_train, X_val, y_val, config):
    """
    Train SVM model
    
    Args:
        model: SVM model instance
        X_train: Training features
        y_train: Training labels
        X_val: Validation features
        y_val: Validation labels
        config: Configuration dictionary
    
    Returns:
        dict: Training results
    """
    print("\n" + "="*70)
    print("Starting SVM training...")
    print("="*70 + "\n")
    
    # Training
    start_time = time.time()
    model.fit(X_train, y_train)
    train_time = time.time() - start_time
    
    print(f"Training completed in {train_time:.2f} seconds")
    
    # Evaluate on training set
    print("\nEvaluating on training set...")
    train_pred = model.predict(X_train)
    train_acc = accuracy_score(y_train, train_pred) * 100
    print(f"Train Accuracy: {train_acc:.2f}%")
    
    # Evaluate on validation set
    print("\nEvaluating on validation set...")
    val_pred = model.predict(X_val)
    val_acc = accuracy_score(y_val, val_pred) * 100
    print(f"Validation Accuracy: {val_acc:.2f}%")
    
    return {
        'train_accuracy': train_acc,
        'val_accuracy': val_acc,
        'train_time': train_time,
        'train_predictions': train_pred,
        'val_predictions': val_pred
    }


def evaluate(model, X_test, y_test):
    """
    Evaluate model on test set
    
    Args:
        model: Trained SVM model
        X_test: Test features
        y_test: Test labels
    
    Returns:
        test_acc, test_predictions
    """
    print("\n" + "="*50)
    print("Evaluating on test set...")
    test_pred = model.predict(X_test)
    test_acc = accuracy_score(y_test, test_pred) * 100
    print(f"Test Accuracy: {test_acc:.2f}%")
    print("="*50)
    
    return test_acc, test_pred
