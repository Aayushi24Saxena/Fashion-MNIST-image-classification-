"""
Experiments package for SVM
"""
