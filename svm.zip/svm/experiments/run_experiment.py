"""
Main experiment runner script for SVM

Usage:
    python models/svm/experiments/run_experiment.py --config models/svm/configs/linear_kernel.yaml
    python models/svm/experiments/run_experiment.py --config models/svm/configs/rbf_kernel.yaml
"""

import sys
import os
import argparse

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

from models.svm.model import get_model
from models.svm.train import train_model, evaluate
from models.svm.evaluate import create_evaluation_report
from models.svm.utils import load_config, get_data_loaders, set_seed


def main(config_path):
    """
    Main training pipeline for SVM
    
    Args:
        config_path: Path to YAML configuration file
    """
    # Load configuration
    print("="*70)
    print("Loading configuration...")
    config = load_config(config_path)
    print(f"Experiment: {config['experiment_name']}")
    print(f"Config: {config_path}")
    print("="*70)
    
    # Set random seed
    set_seed(config.get('seed', 42))
    
    # Load data
    print("\nPreparing data...")
    X_train, y_train, X_val, y_val, X_test, y_test = get_data_loaders(
        config,
        data_root=config.get('data_root', 'data')
    )
    
    # Create model
    print(f"\nCreating SVM model...")
    print(f"Kernel: {config['kernel']}")
    print(f"C: {config['C']}")
    print(f"Gamma: {config.get('gamma', 'scale')}")
    
    model = get_model(
        kernel=config['kernel'],
        C=float(config['C']),
        gamma=config.get('gamma', 'scale'),
        max_iter=int(config.get('max_iter', 1000)),
        decision_function_shape=config.get('decision_function_shape', 'ovr'),
        random_state=config.get('seed', 42)
    )
    
    # Train model
    results = train_model(
        model=model,
        X_train=X_train,
        y_train=y_train,
        X_val=X_val,
        y_val=y_val,
        config=config
    )
    
    # Evaluate on test set
    test_acc, test_pred = evaluate(model, X_test, y_test)
    
    # Save model
    os.makedirs(config['save_dir'], exist_ok=True)
    model_path = f"{config['save_dir']}/{config['experiment_name']}_model.pkl"
    model.save(model_path)
    
    # Create evaluation reports
    print("\nGenerating evaluation reports...")
    eval_dir = os.path.join('images', config['experiment_name'])
    results['test_accuracy'] = test_acc
    create_evaluation_report(results, y_test, test_pred, config, eval_dir)
    
    # Print final summary
    print("\n" + "="*70)
    print("TRAINING COMPLETE")
    print("="*70)
    print(f"Experiment: {config['experiment_name']}")
    print(f"Kernel: {config['kernel']}, C: {config['C']}")
    print(f"Train Accuracy: {results['train_accuracy']:.2f}%")
    print(f"Validation Accuracy: {results['val_accuracy']:.2f}%")
    print(f"Test Accuracy: {test_acc:.2f}%")
    print(f"Training Time: {results['train_time']:.2f} seconds")
    print(f"Model saved to: {model_path}")
    print(f"Evaluation reports saved to: {eval_dir}/")
    print("="*70)
    
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Run SVM experiment with config file')
    parser.add_argument(
        '--config',
        type=str,
        required=True,
        help='Path to YAML configuration file'
    )
    
    args = parser.parse_args()
    
    main(args.config)
