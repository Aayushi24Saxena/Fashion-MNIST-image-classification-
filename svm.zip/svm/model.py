"""
SVM Model for Fashion-MNIST Classification
"""
from sklearn.svm import SVC, LinearSVC
from sklearn.multiclass import OneVsRestClassifier
import joblib


class SVMClassifier:
    """SVM Classifier wrapper for Fashion-MNIST"""
    
    def __init__(self, kernel='rbf', C=1.0, gamma='scale', max_iter=1000, 
                 decision_function_shape='ovr', random_state=42):
        """
        Initialize SVM classifier
        
        Args:
            kernel: Kernel type ('linear', 'rbf', 'poly', 'sigmoid')
            C: Regularization parameter
            gamma: Kernel coefficient for 'rbf', 'poly', 'sigmoid'
            max_iter: Maximum number of iterations
            decision_function_shape: 'ovr' (one-vs-rest) or 'ovo' (one-vs-one)
            random_state: Random seed
        """
        self.kernel = kernel
        self.C = C
        self.gamma = gamma
        self.max_iter = max_iter
        self.decision_function_shape = decision_function_shape
        self.random_state = random_state
        
        # Use LinearSVC for linear kernel (faster)
        if kernel == 'linear':
            self.model = LinearSVC(
                C=C,
                max_iter=max_iter,
                random_state=random_state,
                dual='auto'
            )
        else:
            self.model = SVC(
                kernel=kernel,
                C=C,
                gamma=gamma,
                max_iter=max_iter,
                decision_function_shape=decision_function_shape,
                random_state=random_state,
                cache_size=1000  # Increase cache for faster training
            )
    
    def fit(self, X, y):
        """Train the SVM model"""
        print(f"Training SVM with kernel={self.kernel}, C={self.C}...")
        self.model.fit(X, y)
        return self
    
    def predict(self, X):
        """Make predictions"""
        return self.model.predict(X)
    
    def score(self, X, y):
        """Calculate accuracy score"""
        return self.model.score(X, y)
    
    def save(self, filepath):
        """Save model to disk"""
        joblib.dump(self.model, filepath)
        print(f"✓ Model saved to {filepath}")
    
    def load(self, filepath):
        """Load model from disk"""
        self.model = joblib.load(filepath)
        print(f"✓ Model loaded from {filepath}")
        return self


def get_model(kernel='rbf', C=1.0, gamma='scale', max_iter=1000, 
              decision_function_shape='ovr', random_state=42):
    """
    Factory function to get SVM model
    
    Args:
        kernel: Kernel type ('linear', 'rbf', 'poly', 'sigmoid')
        C: Regularization parameter
        gamma: Kernel coefficient
        max_iter: Maximum iterations
        decision_function_shape: Decision function shape
        random_state: Random seed
    
    Returns:
        SVMClassifier instance
    """
    return SVMClassifier(
        kernel=kernel,
        C=C,
        gamma=gamma,
        max_iter=max_iter,
        decision_function_shape=decision_function_shape,
        random_state=random_state
    )
