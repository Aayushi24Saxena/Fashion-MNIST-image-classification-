"""
Traditional Neural Network Model Architecture for Fashion-MNIST Classification
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class SimpleNN(nn.Module):
    """Simple fully-connected Neural Network for Fashion-MNIST"""
    
    def __init__(self, num_classes=10, dropout_rate=0.0):
        super(SimpleNN, self).__init__()
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(28 * 28, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, num_classes)
        
        # Optional dropout for regularization
        self.dropout = nn.Dropout(dropout_rate) if dropout_rate > 0 else None

    def forward(self, x):
        x = self.flatten(x)
        x = F.relu(self.fc1(x))
        if self.dropout:
            x = self.dropout(x)
        x = F.relu(self.fc2(x))
        if self.dropout:
            x = self.dropout(x)
        x = self.fc3(x)
        return x


class DeeperNN(nn.Module):
    """Deeper fully-connected Neural Network with 4 hidden layers"""
    
    def __init__(self, num_classes=10, dropout_rate=0.3):
        super(DeeperNN, self).__init__()
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(28 * 28, 512)
        self.bn1 = nn.BatchNorm1d(512)
        self.fc2 = nn.Linear(512, 256)
        self.bn2 = nn.BatchNorm1d(256)
        self.fc3 = nn.Linear(256, 128)
        self.bn3 = nn.BatchNorm1d(128)
        self.fc4 = nn.Linear(128, 64)
        self.fc5 = nn.Linear(64, num_classes)
        
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = self.flatten(x)
        x = self.dropout(F.relu(self.bn1(self.fc1(x))))
        x = self.dropout(F.relu(self.bn2(self.fc2(x))))
        x = self.dropout(F.relu(self.bn3(self.fc3(x))))
        x = self.dropout(F.relu(self.fc4(x)))
        x = self.fc5(x)
        return x


class WideNN(nn.Module):
    """Wide fully-connected Neural Network with larger hidden layers"""
    
    def __init__(self, num_classes=10, dropout_rate=0.3):
        super(WideNN, self).__init__()
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(28 * 28, 1024)
        self.bn1 = nn.BatchNorm1d(1024)
        self.fc2 = nn.Linear(1024, 512)
        self.bn2 = nn.BatchNorm1d(512)
        self.fc3 = nn.Linear(512, num_classes)
        
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        x = self.flatten(x)
        x = self.dropout(F.relu(self.bn1(self.fc1(x))))
        x = self.dropout(F.relu(self.bn2(self.fc2(x))))
        x = self.fc3(x)
        return x


def get_model(model_name='simple_nn', num_classes=10, dropout_rate=0.0):
    """Factory function to get model by name"""
    models = {
        'simple_nn': SimpleNN(num_classes, dropout_rate),
        'deeper_nn': DeeperNN(num_classes, dropout_rate),
        'wide_nn': WideNN(num_classes, dropout_rate)
    }
    if model_name not in models:
        raise ValueError(f"Model {model_name} not found. Available: {list(models.keys())}")
    return models[model_name]
