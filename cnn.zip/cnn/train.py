"""
Training and evaluation functions for CNN
"""
import torch
import torch.nn as nn
from tqdm import tqdm


def train_epoch(model, device, train_loader, optimizer, criterion, epoch, total_epochs, wandb_log=True):
    """Train for one epoch"""
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    
    pbar = tqdm(enumerate(train_loader), total=len(train_loader), 
                desc=f"Epoch [{epoch+1}/{total_epochs}]")
    
    for batch_idx, (data, target) in pbar:
        data, target = data.to(device), target.to(device)
        
        optimizer.zero_grad()
        outputs = model(data)
        loss = criterion(outputs, target)
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += target.size(0)
        correct += (predicted == target).sum().item()
        
        # Update progress bar
        pbar.set_postfix({
            'loss': f'{loss.item():.4f}',
            'acc': f'{100.*correct/total:.2f}%'
        })
    
    epoch_loss = running_loss / len(train_loader)
    epoch_acc = 100. * correct / total
    
    return epoch_loss, epoch_acc


def evaluate(model, device, test_loader, criterion):
    """Evaluate model on test/validation set"""
    model.eval()
    test_loss = 0
    correct = 0
    total = 0
    all_preds = []
    all_targets = []
    
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            outputs = model(data)
            test_loss += criterion(outputs, target).item() * data.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total += target.size(0)
            correct += (predicted == target).sum().item()
            
            all_preds.extend(predicted.cpu().numpy())
            all_targets.extend(target.cpu().numpy())
    
    test_loss /= len(test_loader.dataset)
    accuracy = 100. * correct / total
    
    return test_loss, accuracy, all_preds, all_targets


def train_model(model, device, train_loader, val_loader, test_loader, 
                optimizer, criterion, scheduler, config, wandb_run=None):
    """
    Complete training loop with validation and test evaluation
    
    Returns:
        dict: Training history and final metrics
    """
    best_val_accuracy = 0.0
    history = {
        'train_loss': [],
        'train_acc': [],
        'val_loss': [],
        'val_acc': [],
    }
    
    for epoch in range(config['epochs']):
        # Training
        train_loss, train_acc = train_epoch(
            model, device, train_loader, optimizer, criterion, 
            epoch, config['epochs']
        )
        
        # Validation
        val_loss, val_acc, _, _ = evaluate(model, device, val_loader, criterion)
        
        # Update learning rate
        if scheduler:
            scheduler.step()
        
        # Save history
        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)
        
        # Log to WandB
        if wandb_run:
            wandb_run.log({
                'epoch': epoch + 1,
                'train_loss': train_loss,
                'train_acc': train_acc,
                'val_loss': val_loss,
                'val_acc': val_acc,
                'learning_rate': optimizer.param_groups[0]['lr']
            })
        
        print(f"\nEpoch [{epoch+1}/{config['epochs']}]")
        print(f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%")
        print(f"Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.2f}%")
        
        # Save best model
        if val_acc > best_val_accuracy:
            best_val_accuracy = val_acc
            best_model_path = f"{config['save_dir']}/{config['experiment_name']}_best.pth"
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_accuracy': val_acc,
                'config': config
            }, best_model_path)
            print(f"✓ Saved new best model with val accuracy: {best_val_accuracy:.2f}%")
    
    # Final test evaluation
    print("\n" + "="*50)
    print("Evaluating on test set...")
    test_loss, test_acc, test_preds, test_targets = evaluate(model, device, test_loader, criterion)
    print(f"Test Loss: {test_loss:.4f}, Test Accuracy: {test_acc:.2f}%")
    print("="*50)
    
    # Log final test metrics to WandB
    if wandb_run:
        wandb_run.log({
            'test_loss': test_loss,
            'test_acc': test_acc,
            'best_val_acc': best_val_accuracy
        })
    
    return {
        'history': history,
        'best_val_accuracy': best_val_accuracy,
        'test_accuracy': test_acc,
        'test_loss': test_loss,
        'test_predictions': test_preds,
        'test_targets': test_targets
    }
