"""
Evaluation and visualization utilities
"""
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.metrics import confusion_matrix, classification_report
import os


# Fashion-MNIST class names
CLASS_NAMES = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']


def plot_confusion_matrix(y_true, y_pred, save_path=None, wandb_run=None, class_names=None):
    """
    Plot confusion matrix
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        save_path: Path to save the figure
        wandb_run: WandB run object for logging
        class_names: Optional list of class names (defaults to CLASS_NAMES)
    """
    cm = confusion_matrix(y_true, y_pred)
    
    # Use provided class names or default
    labels = class_names if class_names is not None else CLASS_NAMES
    
    # Adjust figure size based on number of classes
    figsize = (6, 5) if len(labels) == 2 else (12, 10)
    
    plt.figure(figsize=figsize)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=labels, yticklabels=labels)
    plt.title('Confusion Matrix', fontsize=16, fontweight='bold')
    plt.ylabel('True Label', fontsize=12)
    plt.xlabel('Predicted Label', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Confusion matrix saved to {save_path}")
    
    if wandb_run:
        wandb_run.log({"confusion_matrix": wandb_run.Image(plt)})
    
    plt.close()


def plot_learning_curves(history, save_path=None, wandb_run=None):
    """
    Plot training and validation loss/accuracy curves
    
    Args:
        history: Dictionary with train/val metrics
        save_path: Path to save the figure
        wandb_run: WandB run object for logging
    """
    epochs = range(1, len(history['train_loss']) + 1)
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
    
    # Loss curves
    ax1.plot(epochs, history['train_loss'], 'b-o', label='Train Loss', linewidth=2, markersize=4)
    ax1.plot(epochs, history['val_loss'], 'r-s', label='Val Loss', linewidth=2, markersize=4)
    ax1.set_xlabel('Epoch', fontsize=12)
    ax1.set_ylabel('Loss', fontsize=12)
    ax1.set_title('Training and Validation Loss', fontsize=14, fontweight='bold')
    ax1.legend(fontsize=11)
    ax1.grid(True, alpha=0.3)
    
    # Accuracy curves
    ax2.plot(epochs, history['train_acc'], 'b-o', label='Train Accuracy', linewidth=2, markersize=4)
    ax2.plot(epochs, history['val_acc'], 'r-s', label='Val Accuracy', linewidth=2, markersize=4)
    ax2.set_xlabel('Epoch', fontsize=12)
    ax2.set_ylabel('Accuracy (%)', fontsize=12)
    ax2.set_title('Training and Validation Accuracy', fontsize=14, fontweight='bold')
    ax2.legend(fontsize=11)
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Learning curves saved to {save_path}")
    
    if wandb_run:
        wandb_run.log({"learning_curves": wandb_run.Image(plt)})
    
    plt.close()


def generate_classification_report(y_true, y_pred, save_path=None):
    """
    Generate and save classification report
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        save_path: Path to save the report
    """
    report = classification_report(y_true, y_pred, target_names=CLASS_NAMES, digits=4)
    
    print("\nClassification Report:")
    print("=" * 80)
    print(report)
    print("=" * 80)
    
    if save_path:
        with open(save_path, 'w') as f:
            f.write("Classification Report\n")
            f.write("=" * 80 + "\n")
            f.write(report)
            f.write("=" * 80 + "\n")
        print(f"✓ Classification report saved to {save_path}")
    
    return report


def plot_sample_predictions(model, device, test_loader, num_samples=16, 
                           save_path=None, wandb_run=None):
    """
    Plot sample predictions with true and predicted labels
    
    Args:
        model: Trained model
        device: Device to run inference on
        test_loader: Test data loader
        num_samples: Number of samples to display
        save_path: Path to save the figure
        wandb_run: WandB run object for logging
    """
    model.eval()
    
    # Get a batch of test images
    data_iter = iter(test_loader)
    images, labels = next(data_iter)
    images, labels = images.to(device), labels.to(device)
    
    # Get predictions
    with torch.no_grad():
        outputs = model(images)
        _, predictions = torch.max(outputs, 1)
    
    # Move to CPU for plotting
    images = images.cpu()
    labels = labels.cpu()
    predictions = predictions.cpu()
    
    # Plot
    rows = 4
    cols = num_samples // rows
    fig, axes = plt.subplots(rows, cols, figsize=(15, 12))
    axes = axes.flatten()
    
    for idx in range(num_samples):
        ax = axes[idx]
        img = images[idx].squeeze()
        true_label = CLASS_NAMES[labels[idx]]
        pred_label = CLASS_NAMES[predictions[idx]]
        
        ax.imshow(img, cmap='gray')
        ax.axis('off')
        
        # Color code: green if correct, red if incorrect
        color = 'green' if labels[idx] == predictions[idx] else 'red'
        ax.set_title(f'True: {true_label}\nPred: {pred_label}', 
                    fontsize=9, color=color, fontweight='bold')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Sample predictions saved to {save_path}")
    
    if wandb_run:
        wandb_run.log({"sample_predictions": wandb_run.Image(plt)})
    
    plt.close()


def create_evaluation_report(results, config, save_dir):
    """
    Create comprehensive evaluation report with all visualizations
    
    Args:
        results: Dictionary with training results
        config: Configuration dictionary
        save_dir: Directory to save all outputs
    """
    import torch
    
    os.makedirs(save_dir, exist_ok=True)
    experiment_name = config['experiment_name']
    
    # 1. Confusion Matrix
    cm_path = os.path.join(save_dir, f'{experiment_name}_confusion_matrix.png')
    plot_confusion_matrix(
        results['test_targets'], 
        results['test_predictions'],
        save_path=cm_path
    )
    
    # 2. Learning Curves
    lc_path = os.path.join(save_dir, f'{experiment_name}_learning_curves.png')
    plot_learning_curves(
        results['history'],
        save_path=lc_path
    )
    
    # 3. Classification Report
    report_path = os.path.join(save_dir, f'{experiment_name}_classification_report.txt')
    generate_classification_report(
        results['test_targets'],
        results['test_predictions'],
        save_path=report_path
    )
    
    print(f"\n✅ All evaluation reports saved to {save_dir}/")
