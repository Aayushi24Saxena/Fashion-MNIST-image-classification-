"""
CNN Model Architecture for Fashion-MNIST Classification
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class CNN(nn.Module):
    """Convolutional Neural Network for Fashion-MNIST"""
    
    def __init__(self, num_classes=10, dropout_rate=0.0):
        super(CNN, self).__init__()
        # 1x28x28 -> 16x28x28 -> 16x14x14
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=16, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(16)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        
        # 16x14x14 -> 32x14x14 -> 32x7x7
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(32)

        self.fc1 = nn.Linear(32*7*7, 128)
        self.fc2 = nn.Linear(128, num_classes)
        
        # Optional dropout for regularization
        self.dropout = nn.Dropout(dropout_rate) if dropout_rate > 0 else None

    def forward(self, x):
        # conv -> batchnorm -> relu -> pool
        x = self.pool(F.relu(self.bn1(self.conv1(x))))
        # conv -> batchnorm -> relu -> pool
        x = self.pool(F.relu(self.bn2(self.conv2(x))))

        x = x.view(-1, 32*7*7)
        # fully connected layer 1
        x = F.relu(self.fc1(x))
        if self.dropout:
            x = self.dropout(x)
        # fully connected layer 2 (no relu)
        x = self.fc2(x)
        return x


class DeeperCNN(nn.Module):
    """Deeper CNN with 3 convolutional layers"""
    
    def __init__(self, num_classes=10, dropout_rate=0.3):
        super(DeeperCNN, self).__init__()
        # 1x28x28 -> 32x28x28 -> 32x14x14
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(32)
        self.pool = nn.MaxPool2d(2, 2)
        
        # 32x14x14 -> 64x14x14 -> 64x7x7
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(64)
        
        # 64x7x7 -> 128x7x7 -> 128x3x3
        self.conv3 = nn.Conv2d(64, 128, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm2d(128)
        
        self.fc1 = nn.Linear(128*3*3, 256)
        self.fc2 = nn.Linear(256, num_classes)
        
        self.dropout = nn.Dropout(dropout_rate)
    
    def forward(self, x):
        x = self.pool(F.relu(self.bn1(self.conv1(x))))
        x = self.pool(F.relu(self.bn2(self.conv2(x))))
        x = self.pool(F.relu(self.bn3(self.conv3(x))))
        
        x = x.view(-1, 128*3*3)
        x = self.dropout(F.relu(self.fc1(x)))
        x = self.fc2(x)
        return x


def get_model(model_name='cnn', num_classes=10, dropout_rate=0.0):
    """Factory function to get model by name"""
    models = {
        'cnn': CNN(num_classes, dropout_rate),
        'deeper_cnn': DeeperCNN(num_classes, dropout_rate)
    }
    if model_name not in models:
        raise ValueError(f"Model {model_name} not found. Available: {list(models.keys())}")
    return models[model_name]
