"""
Utility functions for data loading, config parsing, and WandB setup
"""
import torch
from torch.utils.data import DataLoader, random_split
from torchvision import transforms
from torchvision.datasets import FashionMNIST
import yaml
import os
import wandb


def load_config(config_path):
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config


def get_transforms(augmentation_level='medium'):
    """
    Get data transforms based on augmentation level
    
    Args:
        augmentation_level: 'none', 'light', 'medium', 'heavy'
    
    Returns:
        train_transform, test_transform
    """
    # Normalization values for Fashion-MNIST
    mean = (0.2860,)
    std = (0.3530,)
    
    # Base transforms for test (always the same)
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ])
    
    # Training transforms based on augmentation level
    if augmentation_level == 'none':
        train_transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean, std)
        ])
    elif augmentation_level == 'light':
        train_transform = transforms.Compose([
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean, std)
        ])
    elif augmentation_level == 'medium':
        train_transform = transforms.Compose([
            transforms.RandomCrop(28, padding=2),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean, std)
        ])
    elif augmentation_level == 'heavy':
        train_transform = transforms.Compose([
            transforms.RandomCrop(28, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(15),
            transforms.RandomAffine(degrees=0, translate=(0.1, 0.1)),
            transforms.ToTensor(),
            transforms.Normalize(mean, std)
        ])
    else:
        raise ValueError(f"Unknown augmentation level: {augmentation_level}")
    
    return train_transform, test_transform


def get_data_loaders(config, data_root='data'):
    """
    Create train, validation, and test data loaders
    
    Args:
        config: Configuration dictionary
        data_root: Root directory for datasets
    
    Returns:
        train_loader, val_loader, test_loader
    """
    # Get transforms
    train_transform, test_transform = get_transforms(
        config.get('augmentation', 'medium')
    )
    
    # Load full training dataset
    full_train_dataset = FashionMNIST(
        root=data_root,
        train=True,
        transform=train_transform,
        download=True
    )
    
    # Split training into train and validation
    # Using official split: 50000 train, 10000 validation
    train_size = 50000
    val_size = 10000
    
    train_dataset, val_dataset = random_split(
        full_train_dataset, 
        [train_size, val_size],
        generator=torch.Generator().manual_seed(config.get('seed', 42))
    )
    
    # Load test dataset
    test_dataset = FashionMNIST(
        root=data_root,
        train=False,
        transform=test_transform,
        download=True
    )
    
    # Create data loaders
    train_loader = DataLoader(
        dataset=train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config.get('num_workers', 2),
        pin_memory=True
    )
    
    val_loader = DataLoader(
        dataset=val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config.get('num_workers', 2),
        pin_memory=True
    )
    
    test_loader = DataLoader(
        dataset=test_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config.get('num_workers', 2),
        pin_memory=True
    )
    
    print(f"Train set: {len(train_dataset)} samples")
    print(f"Validation set: {len(val_dataset)} samples")
    print(f"Test set: {len(test_dataset)} samples")
    
    return train_loader, val_loader, test_loader


def setup_wandb(config, api_key=None):
    """
    Initialize WandB for experiment tracking
    
    Args:
        config: Configuration dictionary
        api_key: WandB API key (optional if already logged in)
    
    Returns:
        wandb.Run object
    """
    if api_key:
        wandb.login(key=api_key)
    
    # Initialize WandB run
    run = wandb.init(
        project=config.get('wandb_project', 'fashion-mnist-cnn'),
        name=config['experiment_name'],
        config=config,
        tags=config.get('tags', []),
        notes=config.get('notes', ''),
        reinit=True,
        settings=wandb.Settings(start_method="thread")
    )
    
    return run


def get_optimizer(model, config):
    """
    Get optimizer based on config
    
    Args:
        model: PyTorch model
        config: Configuration dictionary
    
    Returns:
        optimizer
    """
    optimizer_name = config.get('optimizer', 'adam').lower()
    lr = float(config['learning_rate'])
    weight_decay = float(config.get('weight_decay', 0))
    
    if optimizer_name == 'adam':
        optimizer = torch.optim.Adam(
            model.parameters(), 
            lr=lr, 
            weight_decay=weight_decay
        )
    elif optimizer_name == 'adamw':
        optimizer = torch.optim.AdamW(
            model.parameters(), 
            lr=lr, 
            weight_decay=weight_decay
        )
    elif optimizer_name == 'sgd':
        momentum = float(config.get('momentum', 0.9))
        optimizer = torch.optim.SGD(
            model.parameters(), 
            lr=lr, 
            momentum=momentum,
            weight_decay=weight_decay
        )
    else:
        raise ValueError(f"Unknown optimizer: {optimizer_name}")
    
    return optimizer


def get_scheduler(optimizer, config):
    """
    Get learning rate scheduler based on config
    
    Args:
        optimizer: PyTorch optimizer
        config: Configuration dictionary
    
    Returns:
        scheduler (or None if not specified)
    """
    scheduler_name = config.get('scheduler', None)
    
    if scheduler_name is None or scheduler_name == 'none':
        return None
    
    if scheduler_name == 'step':
        step_size = int(config.get('step_size', 10))
        gamma = float(config.get('gamma', 0.1))
        scheduler = torch.optim.lr_scheduler.StepLR(
            optimizer, 
            step_size=step_size, 
            gamma=gamma
        )
    elif scheduler_name == 'cosine':
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, 
            T_max=config['epochs']
        )
    elif scheduler_name == 'reduce_on_plateau':
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='max',
            factor=0.5,
            patience=5,
            verbose=True
        )
    else:
        raise ValueError(f"Unknown scheduler: {scheduler_name}")
    
    return scheduler


def set_seed(seed):
    """Set random seeds for reproducibility"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    import numpy as np
    np.random.seed(seed)
    import random
    random.seed(seed)
    # For deterministic behavior (may impact performance)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
