"""
Main experiment runner script

Usage:
    python models/experiments/run_experiment.py --config models/configs/baseline.yaml
    python models/experiments/run_experiment.py --config models/configs/deeper_network.yaml
"""

import sys
import os
import argparse
import torch
import torch.nn as nn

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

from models.cnn.model import get_model
from models.cnn.train import train_model
from models.cnn.evaluate import create_evaluation_report
from models.cnn.utils import (
    load_config, 
    get_data_loaders, 
    setup_wandb, 
    get_optimizer,
    get_scheduler,
    set_seed
)


def main(config_path, wandb_api_key=None):
    """
    Main training pipeline
    
    Args:
        config_path: Path to YAML configuration file
        wandb_api_key: WandB API key for logging
    """
    # Load configuration
    print("="*70)
    print("Loading configuration...")
    config = load_config(config_path)
    print(f"Experiment: {config['experiment_name']}")
    print(f"Config: {config_path}")
    print("="*70)
    
    # Set random seed
    set_seed(config.get('seed', 42))
    
    # Setup device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nUsing device: {device}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    
    # Initialize WandB
    wandb_run = None
    if wandb_api_key or os.getenv('WANDB_API_KEY'):
        print("\nInitializing WandB...")
        wandb_run = setup_wandb(config, api_key=wandb_api_key)
    else:
        print("\nWarning: No WandB API key provided. Skipping WandB logging.")
    
    # Create data loaders
    print("\nPreparing data loaders...")
    train_loader, val_loader, test_loader = get_data_loaders(
        config, 
        data_root=config.get('data_root', 'data')
    )
    
    # Create model
    print(f"\nCreating model: {config['model_name']}")
    model = get_model(
        model_name=config['model_name'],
        num_classes=10,
        dropout_rate=config.get('dropout_rate', 0.0)
    ).to(device)
    
    # Print model summary
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total parameters: {total_params:,}")
    print(f"Trainable parameters: {trainable_params:,}")
    
    # Setup loss, optimizer, and scheduler
    criterion = nn.CrossEntropyLoss()
    optimizer = get_optimizer(model, config)
    scheduler = get_scheduler(optimizer, config)
    
    print(f"\nOptimizer: {config.get('optimizer', 'adam')}")
    print(f"Learning rate: {config['learning_rate']}")
    print(f"Scheduler: {config.get('scheduler', 'none')}")
    print(f"Augmentation: {config.get('augmentation', 'medium')}")
    
    # Create save directory
    os.makedirs(config['save_dir'], exist_ok=True)
    
    # Train model
    print("\n" + "="*70)
    print("Starting training...")
    print("="*70 + "\n")
    
    results = train_model(
        model=model,
        device=device,
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader,
        optimizer=optimizer,
        criterion=criterion,
        scheduler=scheduler,
        config=config,
        wandb_run=wandb_run
    )
    
    # Create evaluation reports
    print("\nGenerating evaluation reports...")
    eval_dir = os.path.join('images', config['experiment_name'])
    create_evaluation_report(results, config, eval_dir)
    
    # Print final summary
    print("\n" + "="*70)
    print("TRAINING COMPLETE")
    print("="*70)
    print(f"Experiment: {config['experiment_name']}")
    print(f"Best Validation Accuracy: {results['best_val_accuracy']:.2f}%")
    print(f"Final Test Accuracy: {results['test_accuracy']:.2f}%")
    print(f"Test Loss: {results['test_loss']:.4f}")
    print(f"Model saved to: {config['save_dir']}/{config['experiment_name']}_best.pth")
    print(f"Evaluation reports saved to: {eval_dir}/")
    print("="*70)
    
    # Finish WandB run
    if wandb_run:
        wandb_run.finish()
    
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Run CNN experiment with config file')
    parser.add_argument(
        '--config', 
        type=str, 
        required=True,
        help='Path to YAML configuration file'
    )
    parser.add_argument(
        '--wandb-key',
        type=str,
        default=None,
        help='WandB API key (optional, can use WANDB_API_KEY env variable)'
    )
    
    args = parser.parse_args()
    
    main(args.config, args.wandb_key)
